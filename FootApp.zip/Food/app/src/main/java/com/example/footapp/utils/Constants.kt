package com.example.footapp.utils

const val API_DATABASE="https://foot-b4d00-default-rtdb.asia-southeast1.firebasedatabase.app"
const val TOTAL_USER="TOTAL_USER"