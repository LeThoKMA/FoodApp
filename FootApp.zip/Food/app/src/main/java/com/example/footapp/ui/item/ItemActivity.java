package com.example.footapp.ui.item;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.footapp.databinding.ActivityItemBinding;
import com.example.footapp.model.Item;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemActivity extends AppCompatActivity {

    private ActivityItemBinding binding;
    private final List<Item> mListItem = new ArrayList<>();
    private ItemAdapter itemAdapter;
    private ItemPresenter itemPresenter;

    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityItemBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initUI();
        initView();
        initListener();
        getListItem();
    }

    private void initUI() {
        itemPresenter = new ItemPresenter();
        progressDialog = new ProgressDialog(this);
    }


    private void initView() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.rcView.setLayoutManager(linearLayoutManager);
        DividerItemDecoration decoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        binding.rcView.addItemDecoration(decoration);
        itemAdapter = new ItemAdapter(mListItem, new ItemInterface() {
            @Override
            public void deleteItem(int pos, Item item) {
                itemAdapter.remove(pos);
                itemPresenter.deleteItem(pos, item);
                Toast.makeText(getApplicationContext(), "" + pos, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void updateItem(int pos) {
                Dialog dialog = new Dialog(getApplicationContext());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView();
                Window window = dialog.getWindow();
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.setCancelable(false);

                dialog.show();
            }
        });
        binding.rcView.setAdapter(itemAdapter);
    }

    private void getListItem() {
        progressDialog.show();
        List<Item> coffee = new ArrayList<>();
        List<Item> juice = new ArrayList<>();
        List<Item> tea = new ArrayList<>();
        List<Item> smoothie = new ArrayList<>();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference reference = firebaseDatabase.getReference("items");
        reference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Item item = snapshot.getValue(Item.class);
                if (item != null) {
                    if (item.getType().equals("coffee")) {
                        coffee.add(item);
                    } else if (item.getType().equals("tea")) {
                        tea.add(item);
                    } else if (item.getType().equals("juice")) {
                        juice.add(item);
                    } else if (item.getType().equals("smoothie")) {
                        smoothie.add(item);
                    }
                }
                mListItem.clear();
                mListItem.addAll(coffee);
                mListItem.addAll(tea);
                mListItem.addAll(juice);
                mListItem.addAll(smoothie);
                itemAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }

        });

    }

    public void initListener() {
        binding.imvBack.setOnClickListener(v -> finish());
    }
}